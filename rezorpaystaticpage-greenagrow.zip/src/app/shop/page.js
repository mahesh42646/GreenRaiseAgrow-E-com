import MainPage from '../page';

export default function ShopPage() {
  return <MainPage />;
} 