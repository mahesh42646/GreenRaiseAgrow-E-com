import MainPage from '../page';

export default function ProductPage() {
  return <MainPage />;
}